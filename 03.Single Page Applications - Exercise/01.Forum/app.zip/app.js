import { showHome} from './home.js';

document.querySelector("nav a").addEventListener('click', showHome);

showHome();